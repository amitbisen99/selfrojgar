<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\JobIndustry;

class JobIndustryController extends BaseController
{
    public function index(Request $request)
    {
        $jobIndustries = JobIndustry::where('status', 1)->get();
        return $this->sendResponse($jobIndustries, 'Job Industries retrieved successfully.');
    }
}
